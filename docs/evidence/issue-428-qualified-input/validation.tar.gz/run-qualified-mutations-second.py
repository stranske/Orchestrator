import hashlib,json,pathlib,subprocess,sys,xml.etree.ElementTree as ET
repo=pathlib.Path('/Users/teacher/.codex/automations/pd-workloop-resume/worktrees/Orchestrator-428-qualified-retrospective')
out=pathlib.Path(__file__).parent / 'qualified-mutations-second';out.mkdir(exist_ok=False)
paths={n:repo/'src'/n for n in ['roles.py','adjudicator_retro.py']};originals={n:p.read_bytes() for n,p in paths.items()}
base='tests/test_adjudicator_qualified_input.py::'
cases=[
('digest','roles.py','if case not in _COLLECTED_CASES or hashlib.sha256(case._encoded).hexdigest() != case._digest:','if case not in _COLLECTED_CASES:',base+'test_collector_capability_digest_is_rechecked_before_use'),
('inventory','adjudicator_retro.py','or set(declared) != set(actual_paths)','or False',base+'test_unqualified_inventory_or_provenance_never_issues_case[missing-path]'),
('provenance','adjudicator_retro.py','or hashlib.sha256(body.encode()).hexdigest() != provenance.get("pr_body_sha256")','or False',base+'test_unqualified_inventory_or_provenance_never_issues_case[altered-body-hash]'),
('isolation','roles.py','isolate=retrospective_origin,','isolate=False,',base+'test_collector_issued_input_reaches_existing_native_runner_without_truncation'),
('full-prompt','roles.py','case = (\n        ctx.get("case") or {}','case = (\n        {**(ctx.get("case") or {}), "disputed_finding": "TRUNCATED"}',base+'test_collector_issued_input_reaches_existing_native_runner_without_truncation'),
('prompt-budget','adjudicator_retro.py','if len(prompt.encode("utf-8")) > prompt_byte_limit:','if False:',base+'test_complete_prompt_budget_includes_unicode_and_context'),
('evidence-refs','roles.py','if any(ref not in supplied for ref in refs):','if False:',base+'test_qualified_proposal_cannot_cite_absent_evidence'),
('before-blobs','adjudicator_retro.py','before_sources.append(before)','pass',base+'test_modified_sources_include_complete_before_and_after_blobs'),
]
results=[]
try:
 for name,file,old,new,node in cases:
  source=originals[file].decode()
  if source.count(old)!=1: raise RuntimeError('ambiguous mutation '+name)
  paths[file].write_text(source.replace(old,new))
  record={'name':name,'production_file':'src/'+file,'node':node,'original_sha256':hashlib.sha256(originals[file]).hexdigest(),'mutant_sha256':hashlib.sha256(paths[file].read_bytes()).hexdigest()}
  try:
   for phase in ['red','green']:
    if phase=='green': paths[file].write_bytes(originals[file])
    argv=[sys.executable,'-m','pytest','-q',node,'--junitxml='+str(out/(name+'-'+phase+'.xml'))]
    p=subprocess.run(argv,cwd=repo,capture_output=True,text=True)
    (out/(name+'-'+phase+'.log')).write_text(p.stdout+p.stderr)
    record[phase]={'argv':argv,'exit':p.returncode}
    xml=ET.parse(out/(name+'-'+phase+'.xml'));suite=xml.getroot().find('testsuite')
    if suite is None or int(suite.get('tests',0))!=1: raise RuntimeError('wrong testcase cardinality '+name)
    if phase=='red' and (p.returncode!=1 or int(suite.get('failures',0))!=1 or int(suite.get('errors',0))!=0): raise RuntimeError('mutation did not yield actual assertion RED '+name)
    if phase=='green' and (p.returncode!=0 or int(suite.get('failures',0))!=0 or int(suite.get('errors',0))!=0): raise RuntimeError('restored test not GREEN '+name)
   record['restored_sha256']=hashlib.sha256(paths[file].read_bytes()).hexdigest()
   if record['restored_sha256']!=record['original_sha256']: raise RuntimeError('restoration mismatch')
  finally: paths[file].write_bytes(originals[file])
  results.append(record);(out/'index.json').write_text(json.dumps(results,indent=2));print(name,'RED1 GREEN0',flush=True)
finally:
 for file,p in paths.items(): p.write_bytes(originals[file])
