import hashlib,json,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
w=Path('/Users/teacher/.codex/automations/pd-workloop-resume/worktrees/orch533-conflict-20261011');r=Path(__file__).parent;p=w/'src/adapters.py';original=p.read_bytes();old=b'(regex {_seatbelt_quote(pattern)})';new=b'(regex #{_seatbelt_quote(pattern)})';assert original.count(old)==1
results={}
try:
 p.write_bytes(original.replace(old,new))
 for phase in ['red']:
  cmd=['/opt/anaconda3/bin/python3','-m','pytest','tests/test_seatbelt_regex_quoting.py','-q','-o','addopts=',f'--junitxml={r}/533-proof-{phase}.xml']
  v=subprocess.run(cmd,cwd=w,capture_output=True,text=True);(r/f'533-proof-{phase}.log').write_text(v.stdout+v.stderr);cases=list(ET.parse(r/f'533-proof-{phase}.xml').iter('testcase'));assert v.returncode==1 and len(cases)==4 and all(c.find('failure') is not None and c.find('error') is None and c.find('skipped') is None for c in cases);expected={'test_backslash':'AssertionError: write allowed:', 'test_combined':'sandbox-exec: Error reading string', 'test_quote':'sandbox-exec: Error reading string', 'test_regex_metacharacters':'sandbox-exec: unexpected ^ operator'};assert all(expected[c.attrib['name']] in (c.find('failure').text or '') for c in cases);results[phase]={'command':cmd,'exit':v.returncode,'cases':len(cases),'failure':4,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
finally:
 p.write_bytes(original)
assert p.read_bytes()==original
phase='green';cmd=['/opt/anaconda3/bin/python3','-m','pytest','tests/test_seatbelt_regex_quoting.py','-q','-s','-o','addopts=',f'--junitxml={r}/533-proof-{phase}.xml'];v=subprocess.run(cmd,cwd=w,capture_output=True,text=True);(r/f'533-proof-{phase}.log').write_text(v.stdout+v.stderr);cases=list(ET.parse(r/f'533-proof-{phase}.xml').iter('testcase'));assert v.returncode==0 and len(cases)==4 and all(len(c)==0 for c in cases);assert v.stdout.count('native Seatbelt probe: OK')==5;results[phase]={'command':cmd,'exit':v.returncode,'cases':4,'pass':4,'native_probes':5,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};results['original_restored_equal']=True;(r/'533-proof-results.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
