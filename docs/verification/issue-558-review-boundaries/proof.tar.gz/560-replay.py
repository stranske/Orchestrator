import subprocess,hashlib,json
from pathlib import Path
p=Path(__file__).parent;source=Path('src/adversarial.py');before=source.read_bytes();old=subprocess.check_output(['git','show','89a500adfb2ae6663d94c366fcf757fc89b34878:src/adversarial.py']);test=Path('tests/test_issue558_review_boundaries.py');digest=lambda b:hashlib.sha256(b).hexdigest();record={'corrected_sha256':digest(before),'original_sha256':digest(old),'test_sha256':digest(test.read_bytes()),'scope':'Actual original PR560 production bytes and unchanged tests; private Brain; 10 behavioral cases, new checkout API covered separately'}
cmd=['/opt/anaconda3/bin/python3','-m','pytest',str(test),'-k','not merged_checkout and not detached_spawn','-q','-o','addopts=']
try:
 source.write_bytes(old)
 with (p/'560-original-red.log').open('w') as out:r=subprocess.run(cmd+['--junitxml='+str(p/'560-original-red.xml')],stdout=out,stderr=subprocess.STDOUT)
 record['red_exit']=r.returncode
finally:
 source.write_bytes(before)
record['restored_sha256']=digest(source.read_bytes());assert record['restored_sha256']==record['corrected_sha256']
with (p/'560-restored-green.log').open('w') as out:r=subprocess.run(cmd+['--junitxml='+str(p/'560-restored-green.xml')],stdout=out,stderr=subprocess.STDOUT)
record['green_exit']=r.returncode;record['argv']=cmd;(p/'560-production-mutation.json').write_text(json.dumps(record,indent=2));print(json.dumps(record));assert record['red_exit']==1 and record['green_exit']==0
